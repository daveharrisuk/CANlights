/*file: DEFAULTNV.h       This is include file for CANlights.ino sketch
 *----------------------------------------------------------------------------
 * 
 * default NV array for factory reset of module NVs
 *
 *  CANlights control module for 10 channels
 * 
 * Author: Dave Harris. Andover, UK. © Dave Harris 2021
 * 
*/
#ifndef DEFAULTNV_H__  /* include guard */
#define DEFAULTNV_H__

  
  const byte DEFAULTNV[NVSQTY]
  {
  /*  ch0/1 = DayNight, ch2/3 = Dusk, ch4/5 = Dawn, ch6/7 = DuskDawn,
      & ch8/9 = NIGHT010.

                 ch0  ch1  ch2  ch3  ch4  ch5  ch6  ch7  ch8  ch9 */
  /* Transit */    6,   6,   3,   3,   3,   3,   3,   3,   0,   1, 
  /*  Delay0 */    0,   0,   0,   0,   0,   0,   0,   0,   2,   3, 
  /*  Delay1 */    0,   0,   0,   0,   0,   0,   0,   0,   4,   5, 
  /*     DC0 */  250, 251,  32,  33,  34,  35,  36,  37,  38,  39, 
  /*     DC1 */   30,  31, 252, 253, 224, 225, 236, 237, 208, 209, 
  /*    Mode */    0,   0,   1,   1,   2,   2,   3,   3,   4,   4  
  };
  

#endif /* DEFAULTNV_H__ 
 --------------------------------------- EoF ------------------------------
 */
 
